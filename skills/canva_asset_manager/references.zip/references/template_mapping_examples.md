# Template Mapping Examples

Beispiele für Slot-zu-Spalten-Zuordnung:

| Slot-ID | TSV-Spaltenname     | Beschreibung                 |
|----------|--------------------|------------------------------|
| headline_1 | headline_1         | Hauptüberschrift             |
| body_1     | body_1             | Fließtext                    |
| image_1    | image_1_url        | Hauptbild (URL oder Datei)   |
| cta_text   | cta_text           | Call-to-Action Text          |